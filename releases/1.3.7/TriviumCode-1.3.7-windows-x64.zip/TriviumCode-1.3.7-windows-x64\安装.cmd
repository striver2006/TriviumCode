@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or above is required, but "node" was not found on PATH.
  echo Install it from https://nodejs.org/ and reopen the terminal, then run this again.
  goto end
)
node -e "if (Number(process.versions.node.split('.')[0]) < 18) { console.error('Node.js 18 or above is required.'); process.exit(1); }"
if errorlevel 1 goto end
node dist\install.cjs %*
set EC=%errorlevel%
goto finish
:end
set EC=1
:finish
rem keep the window open when launched by double-click; no effect in a terminal
echo %cmdcmdline% | find /i "%~f0" >nul 2>nul
if not errorlevel 1 pause
exit /b %EC%
