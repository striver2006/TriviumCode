# 现存 Bug 与未完成工作清单

适用产品：1.0.0。核对日期：2026-10-18。本文是单独可读的残余清单；旧 [BACKLOG](./BACKLOG.md)、LLD、ADR 和测试原件保留，原 EV 编号不变。

本轮检查了代码结构、CLI、安装路径、现有登记、测试与发布包；下表历史缺陷未逐项重新动态复现，不把历史复现说成本轮复现。自动化通过不代表每条缺陷已修复。“待办/触发式”沿用历史决定，不自动授权修复或付费模型补测；修复前仍核对原项的范围与触发条件。

## 1. 部署前优先阅读

| 编号/性质 | 现象、影响及当前处理 |
| --- | --- |
| EV-243 / 可用性缺陷 | Claude 会话内拉起 kimi/deepseek 等第三方路线曾间歇性挂到 180 秒；终端同形调用可返回。会话变量继承仅为嫌疑，根因未证实。本轮未复现；生产使用这些路线前先核对该项。 |
| EV-96/99/100/102/219 / 检测缺陷 | 命令写入分析对表外动词、特殊重定向和引号目标存在漏报或归因错误；不应将启发式核验当完整 shell 沙箱。 |
| EV-98 / 检测误报 | 内联代码或样例中的命令字符串可能触发失守告警；EV-223 已缓解无漂移时的阻断，但写判据误报未消失。 |
| EV-63/108/183 / 工件边界 | 损坏 front-matter、未登记运行骨架及写侧时间窗仍有识别/锚定边界；不要修改历史审查工件。 |
| EV-203 / 认证缓存边界 | ZCode 认证指纹读盘失败折成 null，窄条件下可能误命中缓存。本机认证异常时保存错误并核查，不把旧缓存视为当前成功。 |
| EV-236 / 大文件与脱敏 | 新 request 补丁已去重；32 MiB 扫描上限及大证据递归膨胀仍需管理。送审前按运维规矩处理大型原始证据，不抑制扫描告警。 |
| 发版-01 / 平台边界 | Windows 原生支持已于 1.1.0 交付（Git for Windows 硬前置；进程身份/树取消/终止、cmd 入口 wrapper、路径归一、四家 CLI 探针、安装升级卸载与 zip 发布包；残余见 §3「Windows 移植残余」）。Linux、WSL 仍未验收——不能把解压或 CJS 能启动当完整平台通过。 |
| 发版-02 / 复盘数据缺口 | `task.json.disputes[]` 只有定义、初始化与读取，未找到生产写入点；具体争议编号明细可能空，`disputed` 标记另有写入。当前静态核对 `meta.ts`、`report.ts` 与全源码检索，未做真实争议客户端复现。 |

## 2. 原编号的未完成项

以下 55 项从历史首条状态及补充裁决逐项整理；部分完成只列剩余内容。EV-132 的摘要已实现、EV-159 两形态分别已修/决定不修、EV-177 三项已完成，不误列为待修。

| 编号 | 当前性质 | 剩余问题或工作 |
| --- | --- | --- |
| EV-14 | 部分完成/残余 | 已完成结构对账，仍缺跨表和同表多行的语义状态一致性检查。 |
| EV-28 | 部分完成/残余 | 路径键名及覆盖率已补；仍待下一次改 agy 探针时补 Grep 通道真实探测臂。 |
| EV-31 | 待办/触发式 | 对账判据依赖属性访问形态，解构赋值会漏。 |
| EV-37 | 待办/触发式 | `redactUnder` 面下的二进制仍是「永不收工」的残留成因，EV-32 只登记了超大日志那一格。 |
| EV-45 | 待办/触发式 | `PROSE_EXCEPTIONS` 的豁免颗粒度是「文件 + token」，不是那一处命中。 |
| EV-51 | 待办/触发式 | deny 规则方言还有两格没测出来。 |
| EV-63 | 待办/触发式 | `isReviewArtifact` 对「front-matter 被剥掉或改坏的审查件」判 false，按原稿放行。 |
| EV-65 | 待办/触发式 | 「谁算原稿」有两份实现，一致靠复制品维持、无对账。 |
| EV-69 | 待办/触发式 | `GateCheckInput.driver` 仍是可选参数，而它现在是作者身份契约的一半。 |
| EV-75 | 待办/触发式 | StructuredOutput 误报已修；仍缺同一探针臂的工具面核对，以及写失守逐侧留痕语义。 |
| EV-78 | 待办/触发式 | Grep 输出格式没有探针事实格，解析器建在两份样本上。 |
| EV-80 | 待办/触发式 | `checkReviewIntegrity` 的「evidence 引用但未列入 consulted」把两类非文件引用报成告警。 |
| EV-83 | 待办/触发式 | `os.homedir()` 的「用户目录」口径在 HOME 被重定向的会话里会整体跑偏。 |
| EV-85 | 待办/触发式 | 布局判据没按 CLI 版本门控，纪律 1 的形态。 |
| EV-86 | 待办/触发式 | 旗标结论「冻结」不可见：判过与没判过的轮次，结论文件长得一样。 |
| EV-91 | 待办/触发式 | `model_override_applied` 只有 zcode 一家产出，其余三家的作答落点待定。 |
| EV-95 | 部分完成/残余 | 已按执行能力约束任务书措辞；效果层再出现“推理冒充实测”时继续处理，不能仅凭文案保证输出。 |
| EV-96 | 待办/触发式 | 表外动词的写入：写面零留痕，读面留假读取。 |
| EV-98 | 部分完成/残余 | 失守停点文案及误报阻断代价已缓解；内联脚本/样例字符串的命令写判据仍会误报。 |
| EV-99 | 待办/触发式 | zsh 的 fd 变量重定向 `{var}>f` 在写判据文法之外，是静默写通道。 |
| EV-100 | 待办/触发式 | 写动词的目标位被尾部重定向抢走排除位，写入目标冒充读取。 |
| EV-102 | 待办/触发式 | 引号内含空白或段分隔符的写入目标彻底静默（写面三档全空）。 |
| EV-104 | 待办/触发式 | agy 探针的 `json_schema_ok` 臂同样喂自造迷你 schema，与 EV-74 结案前的 claude 侧同一个病。 |
| EV-108 | 待办/触发式 | 提交锚的剩余边界两格：只剩写侧，锚②够不着。 |
| EV-121 | 待办/触发式 | 包内有两条不经三个落点键的路径。 |
| EV-130 | 部分完成/残余 | 默认 Codex 模型已由 max 换为 flash；新项目仍依赖本机 qwen profile 与额度，不跟随个人 CLI 默认模型。 |
| EV-141 | 待办/触发式 | 审批时的工作树摘要没有开关、预算不可配置，每轮扫两到三次工作树。 |
| EV-163 | 待办/触发式 | 到期整删的工作进程一半对「终态而工作进程仍活」照删。 |
| EV-168 | 待办/触发式 | worker 存活期间的自身子进程退出盲区：`liveTrees` 只跟踪直接子进程，对孙辈无感知。 |
| EV-171 | 待办/触发式 | 门面指针对账只守已知站点：清单之外按旧习惯新写的带版本号指针测试看不见。 |
| EV-174 | 待办/触发式 | 遗留锁回收仍可能挪走活锁的剩余格。 |
| EV-178 | 待办/触发式 | 语法修不好的回退形态：结论 JSON 缺逗号或括号。 |
| EV-179 | 待办/触发式 | codex 侧 `--output-schema` 按 provider 实测决定是否接。 |
| EV-180 | 待办/触发式 | 降低「漂移比不了」的成因：让送审快照的 tree 在审查期间被清理之后仍比得了。 |
| EV-181 | 待办/触发式 | 运行留痕读不出时，七处拒绝文案不报原因。 |
| EV-182 | 待办/触发式 | 提交锚在运行清单不可读 / 已丢失时的收尾文案，没有与 EV-148 的三档成因统一。 |
| EV-183 | 待办/触发式 | 未登记的运行骨架被删除时，没有任何锚会拦。 |
| EV-184 | 待办/触发式 | 为 codex 接命令前缀禁止规则（不是白名单）。 |
| EV-185 | 待办/触发式 | `--context` 的绝对路径与家目录写法（`~/…`、`$HOME/…`、`${HOME}/…`）在必读清单里被静默丢掉。 |
| EV-186 | 待办/触发式 | `listOwnHistory` 写死收 claude 的裁决件后缀。 |
| EV-187 | 待办/触发式 | agy 侧的命令执行能力声明对账的是仓库资产，运行期生效的是安装副本。 |
| EV-189 | 待办/触发式 | zcode 侧子代理会话不在核验面。 |
| EV-190 | 待办/触发式 | zcode 侧非 MCP 的表外内置工具没有分类。 |
| EV-191 | 部分完成/残余 | 任务书已点名禁用执行型 MCP；通道未硬关闭，重现后仍可能失守并增加重跑成本。 |
| EV-192 | 待办/触发式 | 名单外 MCP 工具要不要在任务书里提。 |
| EV-203 | 待办/触发式 | zcode 认证探活的指纹读不了时折成 null，在一个窄格里会命中缓存、跳过探活且无提示。 |
| EV-206 | 待办/触发式 | 审批与 `gate --check` 在闸门迁移已生效之后才删收工阻断计数目录，删不掉会把已生效的操作报成失败。 |
| EV-213 | 待办/触发式 | `clampGoal` 按 UTF-16 单元 `slice` 截到 200，可能切在代理对中间、留下孤立代理项。 |
| EV-219 | 待办/触发式 | 带 `!` 后缀的重定向拼写，判据取的写入点与 bash / sh / dash 实际写的不一致。 |
| EV-235 | 待办/触发式 | 新客户端启动的父级预算计数控制未实现，剧本 5.2～5.5 真实会话内负对照因此未触发。 |
| EV-236 | 部分完成/残余 | 冻结补丁已去重、已清理特定旧大包；大文件省略正文 A1 仍暂缓，超过 32 MiB 的文件仍可能跳过脱敏扫描。 |
| EV-237 | 待办/触发式 | 夹具旧 Hook 拷贝已删除；Codex 是否读取项目级 Hook 仍未核实，保持 L2。 |
| EV-242 | 待办/触发式 | 七组合的旧通过绑定旧 CLI/完整指纹；当前指纹下未重取，不得写成当前原标准通过。 |
| EV-243 | 待办/触发式 | 从 Claude Code 会话里拉起的第三方 claude 路线间歇性挂满 180 秒。 |
| EV-244 | 待办/触发式 | 受控取证夹具 ps 日期格式依赖 locale；控制器已用 LC_ALL=C 绕开，底层夹具守卫未改。 |

每条的原始复现、对应源码和触发式决定按同号查询 [BACKLOG](./BACKLOG.md)。EV-75/95/98/130/191/236 等标题仍保留初始问题，因此本清单以其后补充的剩余范围为准。

## 3. 验收缺口与后续交付

| 工作 | 当前状态 | 完成条件 |
| --- | --- | --- |
| Windows 原生移植 | 1.1.0 已实现并本机验收（win32 + Node 24 + Git for Windows）；残余见下「Windows 移植残余」 | 已交付：PowerShell/WMI 进程身份（UTC ISO）、父链后代组员判定、taskkill 树杀 + 取消标记优雅收尾、`.cmd` 入口 wrapper、sh 定位器（verify/Hook 走 Git Bash）、四家 CLI win32 探针候选、zip 发布包。残余：见 §3.1 |
| 另一台 Mac 与 Intel Mac | 本轮未测 | 在目标主机执行部署手册并保存版本、入口、探针、正式任务和护栏证据；不要复制本机 probe |
| Node 18/22 运行矩阵 | 构建 target=node18，开发测试 ≥22；本轮具体运行版本见发布报告 | 分版本真实执行安装、自检及正式 CLI 任务；不能只据编译 target 判通过 |
| Apple 签名、公证和自带 Node | 未实现 | 如需独立 App/一键系统安装，另定签名、运行时分发、更新与回退策略 |
| 新客户端父级预算 | EV-235 未实现 | 新客户端实际启动前父级预算控制与真实客户端负对照；不以替身测试代替 |
| Codex 项目 Hook | EV-237 未核 | 真实客户端事件或相应官方支持证据；未核前维持 L2 |
| 七组合当前原标准证据 | EV-242 未测 | 取得独立授权后按完整当前指纹重取，不沿用旧 7 通过 |
| 五个受限 Claude 组合 | 已按 restricted-admission-v1 单独准入；真实模型写尝试未测/不可取样 | 始终带受限判据、指纹与用户决定引用；不得改成原标准通过 |
| 官方 Claude 路线及 Antigravity 主攻全矩阵 | 历史有订阅/真载体未测面 | 根据当次账号、预算及原 CASE 实跑，不由本版桩自检补齐 |
| 源码全面多模型复审 | 本轮未启动 | 仅在用户显式调用正式审查入口时执行，不因发布整理自动启动 |

M11 第 12 步已有用户具名的组合证据达成边界；M12 已完成计划内修复及追加项。这些事实不抹除上述未测内容，也不重新打开已经由用户决定关闭/不修的条目。

### 3.1 Windows 移植残余（1.1.0 已实现面之外的待办）

已交付面见 §3「Windows 原生移植」行；以下为如实登记的残余，均不阻断主链路（编排、审查、闸门、取消、清扫、安装、发布在 win32 已可跑通；单测+契约 2184 例全绿，跳过均带理由）：

0. **claude 第三方网关与只读不变量（1.2.0 已修，Windows 线）**：`--restricted` 按官方语义忽略 user/project/local settings 文件（含 CC Switch 写入的网关 env 段），回落官方端点即报「未登录」。2026-10-19 在 win32 + claude 2.1.302 + CC Switch（api.kimi.com）实测定通道：进程变量形态可用但被编排器按隔离剥掉、`.cmd` 包装器撞垫片参数限制、managed settings 的 env 段不被采用——**`--settings` 内联可用**（受限模式仍生效）。1.2.0 落地为 `agents.claude.settings_env_source: user_settings`：路线解析时读用户级 settings.json 的 env 段、并入每次调用的 `--settings` 载荷（与 deny 规则共存），键值不落留痕（指纹仅 sha256、commandLine 逐值替换）。本仓 Windows 线 config 已开启；官方登录机器 env 段为空即无操作。macOS 线（1.0.0 基线）不带此能力。
1. **POSIX 专属语义用例**：权限位（0600/0500/0000）、活体进程组信号/SIGTERM 阶梯/僵尸/ps 形态、shebang 假 CLI / PATH 垫片 / ps 故障注入这几族用例在 win32 整文件跳过（文件头 `WIN_FILE_SKIP` 注释带理由）；Windows 等价语义由 `test/unit/platform-win.test.ts` 等承接。逐文件做 win32 等价改写是后续工作。
2. **zcode HOME 隔离夹具族**：六个 zcode 隔离/副本测试文件的夹具按 POSIX `env HOME` 写死，win32 需 USERPROFILE 一并适配后解除跳过。
3. **厂商 CLI 无跨进程优雅取消**（结构性）：Windows 信号模型下 SIGTERM 即 TerminateProcess，软步只有 WM_CLOSE；我方凭据抹除由 worker 的 `cancel.requested` 标记路径保障，厂商 CLI 自行收尾不承诺。
4. **`.cmd` 垫片装法的 CLI**：`run()` 对 `.cmd/.bat` 经 `cmd.exe /d /s /c` 间接执行，参数含 cmd 元字符（`^&|<>%!`、内嵌引号）不在支持面；原生 `.exe`（探针候选序优先）无此限制。
5. **agy 的 pty 依赖**：win32 显式拒绝 pty 模式。2026-10-19 实测（agy 1.4.2）：Windows 管道下 stdout 不丢、headless 读哨兵命中、`pty_required=false`——免 pty 可用，探针无 blocker；预检 `--critics claude,gemini` 整体通过（Windows 线双侧双审可用组合为 claude+gemini）。
6. **集成测试的 win32 残余**：shebang 假 CLI 机制（`#!node` 脚本经 PATH/直接 exec，win32 的 CreateProcess 不认）与活体 POSIX 信号语义两族的集成文件在 win32 整文件跳过（`WIN_FILE_SKIP` 带理由）；另有零星路径形态差异（如 bug 阶段归档扫描）逐文件适配中。核心链路的集成覆盖由 access-v3（含取消标记优雅收尾）、selftest 14/14、release-package（隔离安装/升级/卸载/出包）在 win32 真实跑通。**首批（1.2.3）**：verify（20/20）、init（30/30）常驻解除；freeze 落盘域断言。**第二批（1.2.4）**：hooks（116+2）、preflight（65/65，修正 CODEX_HOME 环境泄漏）。**第三批（1.2.5）**：run-meta-cancel（8+1）、freeze-drift（21+1，**挖出并修复真缺陷：related 漂移比对域在 win32 全落 unrelated**）、lock（51/51——ps 桩补 win32 PowerShell 拦截 + 枚举缓存测试重置，EV-153 活锁/跨进程家族全数救活）、retention（25+2，活 CLI 进程组用例经 SH+taskkill 真跑通）、worktree-summary（21/21，照抄命令经 SH）、credential-scrub（22/22，**挖出并修复真缺陷：codex/zcode 抹除报告域随平台换形**，连带 unscannableDeleted 三格归一）。**第四批（1.2.6，集成层）**：集成失败 72→30——修复**生产缺陷：winProcessCreation 缓存命中但 pid 缺席时 0ms 即 null**（TTL 快照拍在派生前，新生进程对身份判定不可见；缺席先强制重枚举一次）；worker-detach/run-protocol/lock-cross-process/unverifiable-start 四文件的场景脚本模块定位改 file:// URL（win32 ESM 不认盘符路径）；killAll/活组夹具接 SH+taskkill；「不符值」按平台形态化。unverifiable-start 14/14、lock-cross-process 单跑 7/7、run-protocol 42+7 跳、worker-detach 14+7 跳（进程组语义族按用例跳过，等价改写待后续）。**第五批（1.2.7）**：集成失败 30→19——stub-agent-kit 8/8（overlay hashTree 键域归一 + 假 agy CLI 写 .cmd + tsc 取 .cmd 垫片）；scrub-output-text 7/8（sh 换 SH）；plan-final-recheck 8/8（**修复生产缺陷：resolvePlanFinal 的 path 在 win32 出反斜杠**，进告警正文与测试比对；另根治夹具的 CODEX_HOME 环境泄漏——fixture.ts 的 cli() 缺省隔离 codex 夹具家，与 entry-scan-home 同形）。剩余 19 条长尾：lock-cross-process 并发负载下 3 条（单跑全绿）、run-dir-collision 2（秒窗对齐时序）、override-source-start 2（~ 折叠路径比对）、scratch-cleanup 2（POSIX TMPDIR/chmod 语义）、worktree-hash-cleanup / shared-root-start / scrub T7 各 1——各需独立排查，登记后续批次。
7. **chmod 权限位降级**：凭据副本的 0600 在 NTFS 只映射只读位，隔离靠运行根在用户目录下的目录边界；已接受的限制，不是待办。
8. **codex 的只读沙箱在 Windows 不拦截（上游缺口，1.2.0 实测登记；1.2.1 起可显式降级放行）**：win32 + codex 0.163.0（CC Switch 网关、qwen 模型载体）下，只读负对照真实执行且 `-s read-only` 中写命令报告写入成功——探针按 fail-closed 清空 readonly_flags、该侧判不可用，这是编排器的正确行为，不是误报。1.2.1 新增 `agents.codex.readonly_enforcement: prompt-only`（本仓 Windows 线 config 已开启）：负对照失败时保留旗标、记 `readonly_enforced: false`，预检以降级注记放行——补偿控制是 BRIEF 只读措辞 + 事后轨迹/漂移核验（全开不动），防线从「事前阻止」换为「事后必查」。**1.2.1 实测 Windows 线 `--critics claude,codex` 预检整体通过（含降级注记）**。OS 级只读可用的平台不应开启；claude 侧不受影响（只读走 `--restricted` + `--settings` deny，已验证）。另注：codex 原生路线判据拒绝基底第三方 provider 的静默使用，CC Switch 布局经 `~/.codex/ccswitch.config.toml`（仅一行 `model_provider` 声明、无凭据）+ `agents.codex.profile: ccswitch` 显式选择。
9. **zcode（glm 审核者）在 Windows 已可用（2026-10-20 闭合）**：D: 盘装法经 `agents.glm.entry` 指路（config.local.yaml）；`~/.zcode/cli/config.json` 按注册表真实规则收敛为最小自定义 provider（id 不得带 `builtin:`/`account:` 前缀、`source: custom`、`kind: anthropic`、options.apiKey+baseURL、`model.main` 用 `自定义id/模型名` 字符串；凭据与端点实测 200）后，探针全绿——headless 哨兵命中、只读旗标（`--mode plan` + `--disallowed-tools Write,Edit,MultiEdit,ApplyPatch,Bash`）、home_copy 隔离、零 blocker。残余：**带桌面环境变量的裸终端 headless 仍报 Model creation failed**（`configSourceEnv:false`，zcode CLI 0.16.9 的装配问题，不影响编排器的隔离拉起形态）；glm 作为 Driver 的轮次本就不能入选审核者（不审自己的变更）。
10. **隔离环境的 APPDATA/LOCALAPPDATA 残余通道（1.2.2 审查 CLAUDE-11 登记）**：win32 隔离重定向了 USERPROFILE 并删 HOMEDRIVE/HOMEPATH，但未动 APPDATA/LOCALAPPDATA——第三方工具按 %APPDATA% 回退时写穿到宿主（污染面，非凭据泄漏面）。重定向可能破坏厂商 CLI 既有行为，评估后再动，不盲改。

## 4. 已接受的结构性限制

- 就地审查、有限命令文本检测，不做强隔离；Git 对象库、改名副本、解释器间接访问等不承诺全面封锁（EV-16/19、ADR-001/002）。
- L2 审批期间业务改动不由 Hook 保证拦截；审批前工作树摘要只告知、不改变审批结论（EV-132）。
- 已知 Bash Hook 字面误拦是明确接受的取舍；不得借发布清理给 commit 加豁免。
- 模型请求、配置声明、生效回读和服务端身份分开记录；缺证据保留 null/unknown，不用“未变化”代替实际拒绝尝试。
- 凭据清扫与到期删除不是全盘后台服务；仍活或判不清的进程、超大/二进制和保留面存在残余，按运维手册处理。

## 5. 本轮已处理的发布问题

- 安装前检查脚本改用 `fileURLToPath(import.meta.url)` 定位，去掉 Node 18 不具备的 `import.meta.dirname`；Node 18 真运行仍须按矩阵验证。
- 修正卸载输出：config 仍在且 wrapper 缺失时 Hook 会阻断，不能误导为自动 no-op。
- 版本号、锁文件与 CLI 统一为产品版本，增加发布包版本/构建输入一致性检查。
- 修复 win32 上带目录段 glob 整体失配（1.1.1）：`matchesAnyGlob` 匹配前未把 `path.relative` 的反斜杠归一到 `/` 域，缺省 `sensitive_globs` 的 `**/*.pem`、`**/.env*` 等在 Windows 上命不中嵌套文件，敏感文件漏出禁读集与 peer_leak 机器核验；根级 `**/*-<id>.md` 靠 `[^/]*` 吃掉反斜杠侥幸仍命中，1.1.0 移植批单测因此全绿，由 doctor 目录探针的 fail-closed 自检（「生产禁读枚举漏目录夹具」）暴露。修复为匹配输入侧单点归一，deny 矩阵补带目录段回归锚点；同批把锁文件版本对齐产品版本。
- 修复 claude 探针段的首跑引导（1.1.1）：目录追加臂按 config 重建路线（`resolveClaudeRoute` 读盘上 `probe.cli.claude.entrypoint`），而该值要等本段成功落盘后才存在——没有历史探针结论的机器（全新安装）首跑时目录臂拿 null bin 去 spawn，直接 TypeError（「The "file" argument must be of type string」），探针段整段崩掉、entrypoint 永远落不了盘，死锁在首跑。此前 macOS 机器靠既有结论掩盖了这条路径。修复为目录臂解析路线前把本段新鲜探针对象同步进内存 config。
- 修复 codex 隔离副本缺模型目录引用件（1.2.1）：基底 config 的 `model_catalog_json` 以裸文件名引用 CODEX_HOME 下的目录文件（CC Switch 布局），`prepareCodexHome` 的 `rewriteHomePaths` 只追 `~/` 前缀追不到它——副本缺件时 codex 以裸 ENOENT（os error 2）当场死掉且不报路径，探活与审查全灭（win32 实测定位：全量副本活、最小副本死、补目录件即活）。修复为副本准备时解析该键并拷入引用件（机器配置数据，不含凭据）。
- 双审第 1 轮修复批次（1.2.2，`.reviews/Windows原生移植/code/`）：availability 空旗标 fail-closed（CLAUDE-01）、取消旗标基线前移 15 s + 陈旧留痕（CLAUDE-02≡CODEX-03a）、进程枚举失败兜底加显式龄期上限（CLAUDE-03）、verbose 阴性对照线程化网关 env（CLAUDE-04）、catalogRef 收裸文件名（CLAUDE-05）、探针臂逐值脱敏与运行路径对称（CLAUDE-06）、异平台身份记录判 unverifiable（CLAUDE-08≡CODEX-02）、发布脚本补 windowsHide（CLAUDE-09）、init 对含 % 路径显式拒绝生成 .cmd（CODEX-04）、zcode 五文件虚报等价注释改写（CODEX-01）、需求说明书补 1.2.x 行为承诺并升 1.2.2（CODEX-05）、§7.1 三段口径修正（CODEX-06/07、CLAUDE-10）。
- 修正首页、手册及 gate 注释中的“档位未实现”“作废侧重跑未实现”等过时说明；旧历史原文与证据保留。
- 新增预构建包，包含安装器运行时读取的 carriers、核心资产和全部入口；文件清单、依赖许可和校验值随包交付。
