@echo off
setlocal
cd /d "%~dp0"
node -e "if (Number(process.versions.node.split('.')[0]) < 18) { console.error('Node.js 18 or above is required.'); process.exit(1); }"
node dist\install.cjs %*
