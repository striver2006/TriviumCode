# 02_系统设计 (System Design)

本目录存放所有系统设计、架构、决策与调研文档，通过文件名前缀区分文档类型。

> **扁平结构的唯一例外**：[`reference/`](./reference/) 子目录。文档中心 [`doc/README.md`](../README.md) 规定各一级目录下不建二级子目录，但本目录同时容纳「**唯一实现依据**」与「多模型答卷等设计输入」两类性质完全不同的文档，且答卷数量会随调研持续增加。若全部平铺，实现者难以一眼分辨哪份是准绳。因此把**非实现依据**的调研材料统一收进 `reference/`，本目录根下只保留正式设计、ADR 与模板。该例外仅限本目录。

---

## 文件命名规范

| 前缀 / 格式 | 文档类型 | 说明 | 示例 |
| :--- | :--- | :--- | :--- |
| `ARCH_<名称>.md` | 总体架构设计 (HLD) | 系统全局上下文、分层架构、核心数据总线、拓扑设计。 | `ARCH_system_overview.md` |
| `LLD_<名称>.md` | 详细设计说明书 (LLD) | 模块级内部设计、状态机、时序图、类与函数签名。 | `LLD_diff_patch_parser.md` |
| `ADR_<编号>_<名称>.md` | 架构决策记录 (ADR) | 关键技术选型与论证记录（背景、评估、决策与影响）。 | [`ADR_TEMPLATE.md`](./ADR_TEMPLATE.md) |
| `PROPOSAL_<名称>.md`<br>或 `YYYY-MM-DD-<主题>.md` | 方案调研与提案 | 针对特定技术挑战的早期提案、竞品调研或多模型答卷。 | `2026-09-10-Claude_Antigravity_ZCode_MultiAgent_Workflow-gemini.md` |

---

## 当前已归档文件

- [系统设计说明书](./系统设计说明书.md)：发布版实现导读；旧总体设计、LLD 与 ADR 保留详细规则及历史决策。

### 唯一实现依据

- [`2026-09-10-Driver-DualCritic主攻双审流水线设计.md`](./2026-09-10-Driver-DualCritic主攻双审流水线设计.md)：**Driver-DualCritic 主攻双审流水线总体架构与详细设计**（当前版本见其文档头，状态：**基线已实现、演进进行中**）。依据 [PRD](../01_requirements/PRD_driver_dual_critic.md)（当前版本见其文档头）与 5 份参考答卷起草。
  演进历程：v1.1.0 按设计审核意见 RV-01～RV-26 修订；v1.2.0 按项目负责人意见 UR-01～UR-06 修订（就地审查、结合全项目评审、Node.js + TypeScript、用户级 skills 载体），均附逐条应答；v1.2.1 按 M0 本机实测回补第 3、10、11、12 章；v1.2.2～v1.2.5 按多轮自举双审加固护栏（含 RV-B1 的实施与撤回）；v1.2.6～v1.2.7 护栏判定范围收窄与 Bash 侧撤回；**v1.3.0 把 M6～M11 的多 Agent 演进并入本文**，新增「实现状态基线」与三级状态标记、纪律 6（回溯颗粒度）与纪律 7（注册表单一来源）、§24 演进并入台账；**v1.3.1～v1.3.6 随 M7b 六步逐步回溯**（`run.v2`、`config.v2`、`--critics` 入口、5.1.1 接入套件与其验收装置——并据桩夹具实测把「五件套」修正为「七件套」、把 `review.v1` 的意见编号前缀由 schema 枚举改为注册表校验）；**v1.3.7 按 M6 四步回填事实表**（3.6 Codex / 3.7 Claude headless 由指针占位翻为已回填，§24 台账三行转绿）——回填推翻了演进设计的三条记载（`-p` 是文件分层而非 `[profiles.*]` 段、effort 档位表全错且 CLI 不校验、模型目录路径名对不上）并修正一条（路径级 deny 对 `Read` 可用、对 `Grep` 不可用）；**v1.3.8 落地 M8 第 1 步的措施 b**（命令文本字面扫描，`10.1`）——它因 codex 的读取经 shell 而成为该侧路径核验的唯一手段，承诺面钉成 **F-1～F-9 必检 / B-1～B-5 明确不可检**的闭集，三处（设计、实现 docblock、用例名）由 `known-forms-parity` 机器对账；**v1.3.9 落地 M8 第 2 步的适配层契约泛化**（`11.1` 新增「轨迹能力与判定分档」）——判定层改为面向 `TraceCapability`（轨迹形态 + 被拒操作是否留痕）而非 Agent id，六个消费点逐一分档；**并推翻 3.6 的一条旧断言**：`rejected_command_in_trace = false` 此前被写成「10.3 的判据对 codex 永久为假」，实为过度推广——被拒的命令不留痕，成功执行的照常留痕，故失守判定两档一律由写事件成立，该字段只修饰阴性结论的可信度；连带新增「无法归因」的漂移分类与两条核验通道的降级留痕（五面）；**v1.3.10～v1.3.12 随 M8 第 3～4 步与 D4-4**（codex 接入为第三家审核者、AC-20 真机验收、codex 进缺省集合）；**v1.3.13～v1.3.16 护栏判定缺口与凭据清扫**；**v1.3.17～v1.3.30 随 M9 七步回溯**（claude 准入实测与三个机读字段、适配器本体与四条准入前置、启用为第四家审核者、`--driver` 全链路、裁决件 `role` 放宽与 Hook 当轮保护集、两轮验收实跑达成完成判据、第 7 步纪律 6 回溯）。
  覆盖架构、组件划分、接口契约、目录与命名规范、操作流程、异常矩阵、实施路线（M0～M11）与验收映射。
  **⚠️ 读法**：正文未加状态标记者描述当前真实系统（M0～M5 基线 + M6～M10b：探针事实、注册表、配置 v2 与动态多审、Codex 与 Claude Code 两家审核者、Driver 护栏与契约面、四家入口资产与真载体验收），以及 M11 已落地的各步（档位全链路、复盘双维度聚合、AC-25 三审检测收口等，正文标【已实现 · M11 第 N 步】）；
  **仍带【待实施 · M\<n\>】标记的才不是现状、不得作为验收依据**——M11/M12 已按主设计台账及各报告的具名达成边界收口，历史阶段说明按当时状态阅读（原 M10 于 2026-09-22 拆为 M10a / M10b，两段均已达成：M10a 2026-09-24、M10b 2026-09-26；v1.3.43 起本句由「M10b 及其后」改为「M11 及其后」，M11 第 10 步起改为按标记判读）。
  **实现与本文冲突时，先回溯修订本文与 PRD，禁止两套规范并行。**

### 详细设计说明书 (LLD)

- [`LLD_orchestrator.md`](./LLD_orchestrator.md)：**编排器详细设计说明书**（当前版本见其文档头，状态：草稿）。面向要维护或修改编排器的工程师，补设计文档与 PROTOCOL 不讲的那一层——各模块的分层地图、主要执行流的调用链、三个核心状态机、贯穿全局的五条实现约束（附「栽过的实例」），以及第七章如实记录的现状缺口（已解决的划线保留）。
  与既有文档的分工：设计文档讲**为什么这么设计**、[`PROTOCOL_dual_critic_relay.md`](../03_api/PROTOCOL_dual_critic_relay.md) 讲**对外契约是什么**、本文讲**代码实际怎么走**。冲突时以设计文档为准。

### 架构决策记录 (ADR)

- [`ADR_003_agent_access.md`](./ADR_003_agent_access.md)：Agent 接入路线与模型族三态决策；历史采样保留，当前版本与收口边界见[2026-10-11恢复报告](../05_testing/REPORT_2026-10-11_agent_access_recovery.md)。
- [`ADR_002_multicritic_isolation.md`](./ADR_002_multicritic_isolation.md)：N 方（多审核者）隔离**只做检测收口，不引入硬隔离**；四条泄漏通道与威胁模型定调，硬隔离路线留档备选。**状态：Accepted（2026-09-13）**，决策者 Chen Zhenbo。关联：设计 10.1 / 10.2、演进设计 §8.2～§8.4。
- [`ADR_001_isolation_mode.md`](./ADR_001_isolation_mode.md)：审查员隔离模式采用**就地审查（in-place）**，不构造冻结镜像树；配三层屏蔽与漂移检测。**状态：Accepted（2026-09-11）**，决策者 Chen Zhenbo（评审意见 UR-03 / UR-06）。
  推翻 v1.0.0～v1.1.0 的 `mirror` 镜像树方案，并因此新增 `agy.path_deny` / `zcode.path_deny` / `agy.scratch_paths` / `zcode.scratch_paths` 四项 M0 探针。关联：设计 AD-05 与第 10 章、PRD FR-07 / FR-10 / FR-15 / FR-16。

### 实施记录

- [`../05_testing/REPORT_2026-09-11_m0_probe.md`](../05_testing/REPORT_2026-09-11_m0_probe.md)：M0 探针本机实测报告（M0 当时的快照；`P-xx` 本机坑清单 M11 第 10 步起在 [`../04_development/GUIDE_local_pitfalls.md`](../04_development/GUIDE_local_pitfalls.md)）。设计原则 P7 规定实现代码只读探针结论、不得硬编码设计文档列出的命令行，本报告是该结论的人读副本（机读副本在 `.trivium/config.local.yaml` 的 `probe:` 段，不进 Git）。

### 受控增量规范（已定稿，效力由主设计逐条授予）

- [`2026-09-13-通用Agent编排与动态多审设计.md`](./2026-09-13-通用Agent编排与动态多审设计.md)：**通用 Agent 编排与动态多审（Driver-MultiCritic）演进设计**（**v1.0.0**，状态：**正式 · 受控增量规范**，2026-09-14 定稿）。依据 2026-09-13 六条演进需求（多模型家族经 Codex 接入含 profile 透传、任意 Agent 可为 Driver、每次审核选 1～3 个审核者、逐审核者模型与思考等级三档、通用扩展架构）起草；提出 Agent 注册表、Driver 运行属性化、N 方隔离与闸门泛化、配置/schema v2、M6～M11 实施路线。
  **它不是独立的实现依据**：条款的规范效力由主设计 §16.1 与 §24「演进并入台账」**逐条显式授予**，
  冲突一律以主设计为准——全仓只有一条规范链，读者从主设计入口。
  **本文自 v1.0.0 起冻结正文**：某条款是否已并入主设计、并入到哪一节，**查主设计 §24 台账，不查本文**。
  另登记既有隔离缺口（归档元数据中的结构化意见不在禁读清单、git 对象库与运行目录为检测盲区）
  并裁定对策：只做检测收口，硬隔离路线留档备选（见下方 ADR-002）。

### 模板

- [`ADR_TEMPLATE.md`](./ADR_TEMPLATE.md)：架构决策记录编写模板

---

## 设计输入（`reference/`，**不作为实现依据**）

以下文档保留其历史价值，但**结论可能已被 v1.2.0 及后续版本推翻**，实现时一律以上方「唯一实现依据」为准。

**设计审核意见**
- [`2026-09-10-Driver-DualCritic主攻双审流水线设计审核意见-claude.md`](./reference/2026-09-10-Driver-DualCritic主攻双审流水线设计审核意见-claude.md)：对 claude 版综合设计 **v1.0.0** 的评审意见（26 条，裁决「有条件通过」）。其横向对比表中的「实现语言 Python」「冻结镜像树 mirror」「命令载体 `.claude/commands/`」三项结论已分别被 AD-12 / ADR-001 / AD-13 推翻。

**其它 Agent 的综合设计答卷**
- [`2026-09-10-Claude-Code主攻双智能体审核流水线-gemini.md`](./reference/2026-09-10-Claude-Code主攻双智能体审核流水线-gemini.md)：Gemini 架构师方案（文内元信息自称「已批准 · 实施基线」，**该口径无效**，本项目的实施基线是上方 claude 版设计）
- [`2026-09-10-Claude-Code主攻双智能体审核流水线-glm.md`](./reference/2026-09-10-Claude-Code主攻双智能体审核流水线-glm.md)：GLM 裁决方案（HLD+LLD，v1.0.0）
- [`2026-09-10-Driver-DualCritic主攻双审流水线设计-zcode.md`](./reference/2026-09-10-Driver-DualCritic主攻双审流水线设计-zcode.md)

**早期多模型答卷**
- [`2026-09-10-Claude-Code主攻双智能体审核流水线-dsv4flash.md`](./reference/2026-09-10-Claude-Code主攻双智能体审核流水线-dsv4flash.md)
- [`2026-09-10-Claude-Code主攻双智能体审核流水线-grok4.6.md`](./reference/2026-09-10-Claude-Code主攻双智能体审核流水线-grok4.6.md)
- [`2026-09-10-Claude-Code主攻双智能体审核流水线-qwen3.8-flash.md`](./reference/2026-09-10-Claude-Code主攻双智能体审核流水线-qwen3.8-flash.md)
- [`2026-09-10-Claude_Antigravity_ZCode_MultiAgent_Workflow-gemini.md`](./reference/2026-09-10-Claude_Antigravity_ZCode_MultiAgent_Workflow-gemini.md)

当前目录事实与敏感枚举规范统一见[设计§3.5](2026-09-10-Driver-DualCritic主攻双审流水线设计.md#agent-access-directory-contract)：消费仅限受测ASCII形态、绑定实际项目及入口，失配回退逐文件。正式授权、实施、真实取证和未测状态见[恢复报告](../05_testing/REPORT_2026-10-11_agent_access_recovery.md)，不以本节历史计划采样替代当前验收。
