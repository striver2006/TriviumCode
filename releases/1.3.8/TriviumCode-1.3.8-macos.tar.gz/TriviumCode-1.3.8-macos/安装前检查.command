#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" != Darwin ]; then
  echo '本包只支持 macOS；Windows 请使用对应的 windows-x64 安装包。' >&2
  exit 1
fi
node -e 'if (Number(process.versions.node.split(".")[0]) < 18) { console.error("需要 Node.js 18 或以上"); process.exit(1); }'
node scripts/install-check.mjs "$@"
